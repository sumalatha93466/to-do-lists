# TaskManager Pro

A professional task management application built with vanilla HTML, CSS, and JavaScript. Features a clean, modern interface with smooth colors designed for professional use.

## Features

- ✅ **Task Management** - Add, edit, delete, and complete tasks
- 🎯 **Priority Levels** - High, Medium, Low with color coding
- 📂 **Categories** - Work, Personal, Shopping, Health
- 📊 **Live Statistics** - Total, completed, and pending task counters
- 🔍 **Smart Filtering** - View all, pending, or completed tasks
- 💾 **Auto-Save** - Tasks persist in browser localStorage
- 📱 **Responsive Design** - Works on desktop, tablet, and mobile
- 🎨 **Professional UI** - Smooth gradients and muted color palette

## Screenshots

![TaskManager Pro Interface](screenshot.png)

## Quick Start

1. Clone or download the repository
2. Open `index.html` in your web browser
3. Start adding tasks and stay organized!

## File Structure

```
TaskManager-Pro/
├── index.html          # Main application structure
├── style.css           # Professional styling and responsive design
├── script.js           # Core functionality and data management
├── explanation.txt     # Detailed code documentation
└── README.md          # This file
```

## Usage

### Adding Tasks
- Type your task in the input field
- Select priority level (High/Medium/Low)
- Choose category (Work/Personal/Shopping/Health)
- Click "+" button or press Enter

### Managing Tasks
- **Complete**: Check the checkbox next to any task
- **Edit**: Hover over task and click edit icon
- **Delete**: Hover over task and click delete icon
- **Filter**: Use tabs to view All, Pending, or Completed tasks
- **Bulk Delete**: Use "Clear Completed" to remove all finished tasks

## Technical Details

- **Frontend**: Vanilla HTML5, CSS3, JavaScript (ES6+)
- **Storage**: Browser localStorage for data persistence
- **Icons**: Font Awesome 6.0 for professional iconography
- **Responsive**: Mobile-first design with CSS Grid and Flexbox
- **Browser Support**: Modern browsers (Chrome, Firefox, Safari, Edge)

## Key Features Explained

### Professional Design
- Smooth color palette with muted tones
- Subtle gradients and shadows
- Clean typography using system fonts
- Consistent spacing and visual hierarchy

### Data Management
- Tasks stored locally in browser
- Auto-save every 30 seconds
- Includes creation and completion dates
- Secure HTML escaping for user input

### User Experience
- Confirmation dialogs for destructive actions
- Hover effects and smooth animations
- Auto-focus on input field
- Empty state guidance for new users

## Customization

### Colors
Edit the CSS variables in `style.css` to change the color scheme:
```css
/* Primary gradient */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Background gradient */
background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
```

### Categories
Add new categories in `script.js`:
```javascript
<option value="newcategory">New Category</option>
```

## Browser Compatibility

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## License

MIT License - feel free to use this project for personal or commercial purposes.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Support

For issues or questions, please open an issue on GitHub.

---

**TaskManager Pro** - Professional task management made simple.