let tasks = JSON.parse(localStorage.getItem('taskManagerPro')) || [];
let currentFilter = 'all';

function addTask() {
    const input = document.getElementById('taskInput');
    const priority = document.getElementById('prioritySelect').value;
    const category = document.getElementById('categorySelect').value;
    const text = input.value.trim();
    
    if (!text) {
        input.focus();
        return;
    }
    
    const task = {
        id: Date.now(),
        text,
        priority,
        category,
        completed: false,
        createdAt: new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        }),
        completedAt: null
    };
    
    tasks.unshift(task);
    input.value = '';
    saveTasks();
    render();
    
    // Add subtle animation feedback
    const addBtn = document.querySelector('.add-task-btn');
    addBtn.style.transform = 'scale(0.95)';
    setTimeout(() => addBtn.style.transform = '', 150);
}

function toggleTask(id) {
    const task = tasks.find(t => t.id == id);
    task.completed = !task.completed;
    task.completedAt = task.completed ? new Date().toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    }) : null;
    saveTasks();
    render();
}

function deleteTask(id) {
    if (confirm('Are you not intrested in this task?')) {
        tasks = tasks.filter(t => t.id != id);
        saveTasks();
        render();
    }
}

function editTask(id) {
    const task = tasks.find(t => t.id == id);
    const newText = prompt('Edit task:', task.text);
    if (newText && newText.trim() && newText.trim() !== task.text) {
        task.text = newText.trim();
        saveTasks();
        render();
    }
}

function filterTasks(filter) {
    currentFilter = filter;
    document.querySelectorAll('.filter-tab').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.filter === filter);
    });
    render();
}

function clearCompleted() {
    const completedCount = tasks.filter(t => t.completed).length;
    if (completedCount === 0) {
        alert('No completed tasks to clear.');
        return;
    }
    
    if (confirm(`Delete ${completedCount} completed task${completedCount > 1 ? 's' : ''}?`)) {
        tasks = tasks.filter(t => !t.completed);
        saveTasks();
        render();
    }
}

function getFilteredTasks() {
    switch(currentFilter) {
        case 'pending': return tasks.filter(t => !t.completed);
        case 'completed': return tasks.filter(t => t.completed);
        default: return tasks;
    }
}

function updateStats() {
    const total = tasks.length;
    const completed = tasks.filter(t => t.completed).length;
    const pending = total - completed;
    
    document.getElementById('totalTasks').textContent = total;
    document.getElementById('completedTasks').textContent = completed;
    document.getElementById('pendingTasks').textContent = pending;
}

function saveTasks() {
    localStorage.setItem('taskManagerPro', JSON.stringify(tasks));
}

function render() {
    const filteredTasks = getFilteredTasks();
    const taskList = document.getElementById('taskList');
    const emptyState = document.getElementById('emptyState');
    
    updateStats();
    
    if (filteredTasks.length === 0) {
        taskList.innerHTML = '';
        emptyState.classList.remove('hidden');
    } else {
        emptyState.classList.add('hidden');
        taskList.innerHTML = filteredTasks.map(task => `
            <li class="task-item ${task.completed ? 'completed' : ''}">
                <input type="checkbox" 
                       class="task-checkbox" 
                       ${task.completed ? 'checked' : ''} 
                       onchange="toggleTask(${task.id})">
                
                <div class="task-content">
                    <div class="task-text">${escapeHtml(task.text)}</div>
                    <div class="task-meta">
                        <span class="task-priority ${task.priority}">${task.priority}</span>
                        <span class="task-category">${task.category}</span>
                        <span class="task-date">
                            Created: ${task.createdAt}
                            ${task.completedAt ? ` • Completed: ${task.completedAt}` : ''}
                        </span>
                    </div>
                </div>
                
                <div class="task-actions">
                    <button class="task-btn edit-btn" 
                            onclick="editTask(${task.id})" 
                            title="Edit task">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="task-btn delete-btn" 
                            onclick="deleteTask(${task.id})" 
                            title="Delete task">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </li>
        `).join('');
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        addTask();
    }
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('taskInput');
    taskInput.addEventListener('keypress', handleKeyPress);
    taskInput.focus();
    render();
    
    // Auto-save every 30 seconds as backup
    setInterval(saveTasks, 30000);
});